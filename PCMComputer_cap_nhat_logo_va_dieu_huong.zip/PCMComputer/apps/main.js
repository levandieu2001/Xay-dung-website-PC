// ========= chuyen anh ==========
const slides = document.querySelectorAll(".img-all img");
const dots = document.querySelectorAll(".dot");
let currentIndex = 0;
function updateSlide() {
  if (slides.length === 0) return;
  const translateXValue = currentIndex * -100;
  slides.forEach((slide) => {
    slide.style.transform = `translateX(${translateXValue}%)`;
  });
  if (dots.length > 0) {
    dots.forEach((dot) => dot.classList.remove("active"));
    if (dots[currentIndex]) {
      dots[currentIndex].classList.add("active");
    }
  }
}

function nextSlide() {
  currentIndex++;

  if (currentIndex >= slides.length) {
    currentIndex = 0;
  }
  updateSlide();
}
if (slides.length > 0) {
  let slideInterval = setInterval(nextSlide, 4000);
  dots.forEach((dot, index) => {
    dot.addEventListener("click", () => {
      currentIndex = index;
      updateSlide();

      clearInterval(slideInterval);
      slideInterval = setInterval(nextSlide, 4000);
    });
  });
}

// ==== Kiem Tra =====
const contactForm = document.getElementById("contactForm");

if (contactForm && document.getElementById("fullname")) {
  contactForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const fullname = document.getElementById("fullname").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const email = document.getElementById("email").value.trim();
    const content = document.getElementById("content").value.trim();

    if (fullname === "") {
      alert("Vui lòng nhập Họ và tên của bạn!");
      document.getElementById("fullname").focus();
      return;
    }

    const phoneRegex = /^0\d{9}$/;

    if (phone === "") {
      alert("Vui lòng nhập Số điện thoại!");
      document.getElementById("phone").focus();
      return;
    } else if (!phoneRegex.test(phone)) {
      alert("Số điện thoại không hợp lệ! (Phải có 10 số và bắt đầu bằng số 0)");
      document.getElementById("phone").focus();
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (email === "") {
      alert("Vui lòng nhập Email!");
      document.getElementById("email").focus();
      return;
    } else if (!emailRegex.test(email)) {
      alert("Email không đúng định dạng! (Ví dụ: abc@gmail.com)");
      document.getElementById("email").focus();
      return;
    }

    if (content === "") {
      alert("Vui lòng nhập Nội dung cần hỗ trợ!");
      document.getElementById("content").focus();
      return;
    }

    alert("Gửi thông tin thành công! Chúng tôi sẽ liên hệ lại sớm nhất.");

    contactForm.reset();
  });
}

// ===== Bo loc danh muc (giao dien chua ket noi database) =====
document.querySelectorAll(".category-filter").forEach((filterCard) => {
  const applyButton = filterCard.querySelector(".btn-filter");
  const resetButton = filterCard.querySelector(".btn-filter-reset");
  const status = filterCard.querySelector(".filter-status");

  if (applyButton && status) {
    applyButton.addEventListener("click", () => {
      status.textContent = "Đã ghi nhận các tiêu chí bạn chọn. Kết quả lọc sẽ được hiển thị sau khi kết nối database.";
    });
  }

  if (resetButton) {
    resetButton.addEventListener("click", () => {
      filterCard.querySelectorAll("select").forEach((select) => {
        select.selectedIndex = 0;
      });
      if (status) {
        status.textContent = "Đã xóa các tiêu chí lọc. Bộ lọc hiện chưa kết nối database.";
      }
    });
  }
});


// ===== Mega menu: mo khi hover, giu mo den khi click ngoai hoac hover muc khac =====
(function () {
  const menuBar = document.querySelector('.menu-bar');
  const navList = menuBar ? menuBar.querySelector('.category-nav-list') : null;
  const menuItems = Array.from(document.querySelectorAll('.category-menu-item'));
  if (!menuBar || !navList || menuItems.length === 0) return;

  const touchMode = window.matchMedia('(hover: none), (pointer: coarse)').matches;

  function closeAllMenus(exceptItem) {
    menuItems.forEach((item) => {
      if (item !== exceptItem) {
        item.classList.remove('is-open');
        const link = item.querySelector('.category-menu-link');
        if (link) link.setAttribute('aria-expanded', 'false');
      }
    });
  }

  function openMenu(item) {
    closeAllMenus(item);
    item.classList.add('is-open');
    const link = item.querySelector('.category-menu-link');
    if (link) link.setAttribute('aria-expanded', 'true');
  }

  navList.addEventListener('mouseover', (event) => {
    const item = event.target.closest('.category-menu-item');
    const homeItem = event.target.closest('.home-menu-item');

    if (homeItem && navList.contains(homeItem)) {
      closeAllMenus(null);
      return;
    }

    if (item && navList.contains(item) && !item.contains(event.relatedTarget)) {
      if (!touchMode) openMenu(item);
    }
  });

  menuItems.forEach((item) => {
    const link = item.querySelector('.category-menu-link');
    if (!link) return;

    link.addEventListener('focus', () => openMenu(item));

    link.addEventListener('click', (event) => {
      if (!touchMode) return;

      const alreadyOpen = item.classList.contains('is-open');
      if (!alreadyOpen) {
        event.preventDefault();
        openMenu(item);
      }
    });
  });

  // Hover cac nut chinh khac (logo, dang nhap, gio hang, Trang chu) se dong menu dang mo.
  document.addEventListener('mouseover', (event) => {
    const otherButton = event.target.closest('.top-nav .header-action, .top-nav .logo2 a, .menu-bar .home-menu-link, button');
    if (otherButton && !event.target.closest('.mega-menu')) {
      closeAllMenus(null);
    }
  });

  // Menu chi dong khi click ra ngoai thanh danh muc.
  document.addEventListener('click', (event) => {
    if (!event.target.closest('.menu-bar')) {
      closeAllMenus(null);
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeAllMenus(null);
  });
})();

// ===== Kiem tra giao dien dang nhap (chua ket noi he thong tai khoan) =====
(function () {
  const button = document.getElementById('loginButton');
  if (!button) return;

  button.addEventListener('click', () => {
    const username = document.getElementById('loginEmail');
    const password = document.getElementById('loginPassword');

    if (!username || username.value.trim() === '') {
      alert('Vui lòng nhập email hoặc tên đăng nhập.');
      if (username) username.focus();
      return;
    }

    if (!password || password.value.trim() === '') {
      alert('Vui lòng nhập mật khẩu.');
      if (password) password.focus();
      return;
    }

    alert('Giao diện đăng nhập đã sẵn sàng. Chức năng xác thực sẽ được bổ sung khi kết nối hệ thống tài khoản.');
  });
})();
