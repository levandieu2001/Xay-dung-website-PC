<%@ Page Language="C#" MasterPageFile="~/Site.Master" %>
<asp:Content ID="MainContentPage" ContentPlaceHolderID="MainContent" runat="server">
    <section class="account-page login-page">
        <div class="account-breadcrumb"><a href="TrangChu.aspx">Trang chủ</a><span>/</span><span>Đăng nhập</span></div>
        <div class="login-layout">
            <div class="login-intro">
                <div class="account-brand-icon"><i class="fa-solid fa-user-shield"></i></div>
                <p class="account-eyebrow">TÀI KHOẢN PCM COMPUTER</p>
                <h1>Chào mừng bạn quay trở lại</h1>
                <p>Đăng nhập để quản lý thông tin mua hàng và thuận tiện theo dõi các hoạt động tại PCM Computer.</p>
                <div class="login-benefits">
                    <div><i class="fa-solid fa-box"></i><span>Theo dõi tình trạng đơn hàng</span></div>
                    <div><i class="fa-solid fa-shield-halved"></i><span>Quản lý thông tin bảo hành</span></div>
                    <div><i class="fa-solid fa-headset"></i><span>Nhận hỗ trợ khi cần thiết</span></div>
                </div>
            </div>
            <div class="account-panel login-panel">
                <div class="account-panel-heading">
                    <h2>Đăng nhập</h2>
                    <p>Nhập thông tin tài khoản của bạn.</p>
                </div>
                <div class="account-field">
                    <label for="loginEmail">Email hoặc tên đăng nhập</label>
                    <div class="account-input-wrap"><i class="fa-regular fa-user"></i><input id="loginEmail" type="text" placeholder="Nhập email hoặc tên đăng nhập" autocomplete="username"></div>
                </div>
                <div class="account-field">
                    <label for="loginPassword">Mật khẩu</label>
                    <div class="account-input-wrap"><i class="fa-solid fa-lock"></i><input id="loginPassword" type="password" placeholder="Nhập mật khẩu" autocomplete="current-password"></div>
                </div>
                <div class="login-options">
                    <label class="remember-option"><input id="rememberLogin" type="checkbox"><span>Ghi nhớ đăng nhập</span></label>
                    <a href="mailto:cskh@pcmcomputer.vn?subject=Ho%20tro%20quen%20mat%20khau">Quên mật khẩu?</a>
                </div>
                <button type="button" class="account-primary-button" id="loginButton"><i class="fa-solid fa-right-to-bracket"></i> Đăng nhập</button>
                <div class="account-note"><i class="fa-solid fa-circle-info"></i><span>Chức năng xác thực tài khoản sẽ được kích hoạt khi website kết nối hệ thống tài khoản.</span></div>
            </div>
        </div>
    </section>
</asp:Content>
