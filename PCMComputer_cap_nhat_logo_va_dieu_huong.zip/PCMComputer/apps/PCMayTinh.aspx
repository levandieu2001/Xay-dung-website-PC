<%@ Page Language="C#" MasterPageFile="~/Site.Master" %>
<asp:Content ID="MainContentPage" ContentPlaceHolderID="MainContent" runat="server">
    <section class="category-page">
        <div class="category-heading">
            <div class="breadcrumb"><a href="TrangChu.aspx">Trang chủ</a> / <span>PC/Máy tính</span></div>
            <h1>PC - Máy tính để bàn</h1>
            <p>Tìm PC theo thương hiệu, cấu hình và mức giá phù hợp với nhu cầu của bạn.</p>
        </div>



        <div class="category-tip">
            <i class="fa-solid fa-circle-info"></i>
            <span>Di chuột vào hoặc chạm vào mục <strong>PC/Máy tính</strong> trên thanh danh mục phía trên để mở bộ lọc.</span>
        </div>

        <div class="category-empty">
            <i class="fa-solid fa-computer"></i>
            <h3>Chưa có sản phẩm PC</h3>
            <p>Sản phẩm sẽ được hiển thị tại đây sau khi tích hợp database.</p>
        </div>
    </section>
</asp:Content>
