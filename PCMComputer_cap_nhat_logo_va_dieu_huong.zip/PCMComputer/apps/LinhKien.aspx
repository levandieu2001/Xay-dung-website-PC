<%@ Page Language="C#" MasterPageFile="~/Site.Master" %>
<asp:Content ID="MainContentPage" ContentPlaceHolderID="MainContent" runat="server">
    <section class="category-page">
        <div class="category-heading">
            <div class="breadcrumb"><a href="TrangChu.aspx">Trang chủ</a> / <span>Linh kiện</span></div>
            <h1>Linh kiện máy tính</h1>
            <p>Lọc linh kiện theo nhóm sản phẩm, thương hiệu và mức giá để xây dựng cấu hình phù hợp.</p>
        </div>



        <div class="category-tip">
            <i class="fa-solid fa-circle-info"></i>
            <span>Di chuột vào hoặc chạm vào mục <strong>Linh kiện</strong> trên thanh danh mục phía trên để mở bộ lọc.</span>
        </div>

        <div class="category-empty">
            <i class="fa-solid fa-microchip"></i>
            <h3>Chưa có sản phẩm linh kiện</h3>
            <p>Sản phẩm sẽ được hiển thị tại đây sau khi tích hợp database.</p>
        </div>
    </section>
</asp:Content>
