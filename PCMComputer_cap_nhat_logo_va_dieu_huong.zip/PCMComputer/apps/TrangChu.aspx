<%@ Page Language="C#" MasterPageFile="~/Site.Master" %>
<asp:Content ID="MainContentPage" ContentPlaceHolderID="MainContent" runat="server">
    <div class="main-content">
        <div class="container">
            <div class="mid">
                <div class="mid-top1">
                    <div class="img-all">
                        <img src="./Image/sale.jpg" alt="Banner khuyến mãi" class="active">
                        <img src="./Image/sale2.jpg" alt="Banner khuyến mãi">
                        <img src="./Image/sale3.jpg" alt="Banner khuyến mãi">
                        <img src="./Image/sale4.jpg" alt="Banner khuyến mãi">
                        <img src="./Image/sale5.jpg" alt="Banner khuyến mãi">
                        <img src="./Image/sale6.jpg" alt="Banner khuyến mãi">
                        <img src="./Image/sale7.jpg" alt="Banner khuyến mãi">
                        <img src="./Image/sale8.jpg" alt="Banner khuyến mãi">
                        <img src="./Image/sale9.jpg" alt="Banner khuyến mãi">
                        <img src="./Image/sale10.jpg" alt="Banner khuyến mãi">
                    </div>
                </div>
                <div class="mid-top2">
                    <div class="dots">
                        <span class="dot active"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                    </div>
                </div>
                <div class="mid-bottom">
                    <div class="content-mid-bottom">
                        <a href="#"><img src="./Image/a1.png" alt="Ưu đãi PCM Computer"></a>
                        <a href="#"><img src="./Image/a2.png" alt="Ưu đãi PCM Computer"></a>
                        <a href="#"><img src="./Image/a3.png" alt="Ưu đãi PCM Computer"></a>
                    </div>
                </div>
            </div>
            <div class="right">
                <div class="img-gift">
                    <img src="./Image/gift1.png" alt="Quà tặng">
                    <img src="./Image/gift2.png" alt="Quà tặng">
                </div>
            </div>
        </div>
    </div>
</asp:Content>
