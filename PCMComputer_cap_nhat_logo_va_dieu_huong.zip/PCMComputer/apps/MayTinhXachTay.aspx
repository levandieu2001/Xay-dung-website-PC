<%@ Page Language="C#" MasterPageFile="~/Site.Master" %>
<asp:Content ID="MainContentPage" ContentPlaceHolderID="MainContent" runat="server">
    <section class="category-page">
        <div class="category-heading">
            <div class="breadcrumb"><a href="TrangChu.aspx">Trang chủ</a> / <span>Laptop</span></div>
            <h1>Laptop - Máy tính xách tay</h1>
            <p>Lựa chọn laptop theo thương hiệu, giá bán, kích thước màn hình và cấu hình.</p>
        </div>



        <div class="category-tip">
            <i class="fa-solid fa-circle-info"></i>
            <span>Di chuột vào hoặc chạm vào mục <strong>Laptop</strong> trên thanh danh mục phía trên để mở bộ lọc.</span>
        </div>

        <div class="category-empty">
            <i class="fa-solid fa-laptop"></i>
            <h3>Chưa có sản phẩm Laptop</h3>
            <p>Sản phẩm sẽ được hiển thị tại đây sau khi tích hợp database.</p>
        </div>
    </section>
</asp:Content>
