<%@ Page Language="C#" MasterPageFile="~/Site.Master" %>
<asp:Content ID="MainContentPage" ContentPlaceHolderID="MainContent" runat="server">
    <section class="category-page">
        <div class="category-heading">
            <div class="breadcrumb"><a href="TrangChu.aspx">Trang chủ</a> / <span>Phụ kiện</span></div>
            <h1>Phụ kiện máy tính</h1>
            <p>Tìm các phụ kiện hỗ trợ làm việc, học tập, giải trí và hoàn thiện góc máy tính.</p>
        </div>



        <div class="category-tip">
            <i class="fa-solid fa-circle-info"></i>
            <span>Di chuột vào hoặc chạm vào mục <strong>Phụ kiện</strong> trên thanh danh mục phía trên để mở bộ lọc.</span>
        </div>

        <div class="category-empty">
            <i class="fa-solid fa-headphones"></i>
            <h3>Chưa có sản phẩm phụ kiện</h3>
            <p>Sản phẩm sẽ được hiển thị tại đây sau khi tích hợp database.</p>
        </div>
    </section>
</asp:Content>
