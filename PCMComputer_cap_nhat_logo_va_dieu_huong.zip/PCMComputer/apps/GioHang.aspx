<%@ Page Language="C#" MasterPageFile="~/Site.Master" %>
<asp:Content ID="MainContentPage" ContentPlaceHolderID="MainContent" runat="server">
    <section class="account-page cart-page">
        <div class="account-breadcrumb"><a href="TrangChu.aspx">Trang chủ</a><span>/</span><span>Giỏ hàng</span></div>
        <div class="cart-heading">
            <div><p class="account-eyebrow">MUA SẮM TẠI PCM COMPUTER</p><h1>Giỏ hàng của bạn</h1><p>Kiểm tra các sản phẩm bạn dự định mua trước khi tiến hành đặt hàng.</p></div>
            <div class="cart-heading-icon"><i class="fa-solid fa-cart-shopping"></i></div>
        </div>
        <div class="cart-empty-panel">
            <div class="cart-empty-icon"><i class="fa-solid fa-basket-shopping"></i></div>
            <h2>Giỏ hàng hiện đang trống</h2>
            <p>Bạn chưa có sản phẩm nào trong giỏ hàng. Hãy khám phá các danh mục để tìm sản phẩm phù hợp.</p>
            <div class="cart-actions">
                <a class="account-primary-button" href="TrangChu.aspx"><i class="fa-solid fa-house"></i> Về trang chủ</a>
                <a class="account-secondary-button" href="PhuKien.aspx"><i class="fa-solid fa-headphones"></i> Khám phá phụ kiện</a>
            </div>
        </div>
        <div class="cart-help-grid">
            <div class="cart-help-item"><i class="fa-solid fa-truck-fast"></i><div><h3>Thông tin giao hàng</h3><p>Thông tin vận chuyển sẽ được hiển thị khi hoàn thiện chức năng đặt hàng.</p></div></div>
            <div class="cart-help-item"><i class="fa-solid fa-credit-card"></i><div><h3>Thanh toán</h3><p>Các phương thức thanh toán sẽ được bổ sung ở bước triển khai giỏ hàng.</p></div></div>
            <div class="cart-help-item"><i class="fa-solid fa-headset"></i><div><h3>Cần hỗ trợ?</h3><p>Liên hệ <a href="LienHe.aspx">PCM Computer</a> để được tư vấn sản phẩm.</p></div></div>
        </div>
        <p class="cart-system-note"><i class="fa-solid fa-circle-info"></i> Giỏ hàng hiện là giao diện chuẩn bị, chưa lưu sản phẩm hoặc tạo đơn hàng.</p>
    </section>
</asp:Content>
