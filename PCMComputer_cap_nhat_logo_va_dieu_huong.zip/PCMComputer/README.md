# PCM Computer — ASP.NET Web Forms

Dự án ASP.NET Web Site (C#), sử dụng .NET Framework 4.8 và Master Page.

## Chạy bằng Visual Studio

1. Cài Visual Studio với workload **ASP.NET and web development** và .NET Framework 4.8 targeting pack.
2. Mở `PCMComputer.sln` (hoặc File > Open > Web Site, chọn thư mục `apps`).
3. Chọn `TrangChu.aspx` làm Start Page, sau đó chạy bằng IIS Express (Ctrl+F5).

## Chạy bằng IIS Express

Trong PowerShell:

```powershell
& 'C:\Program Files\IIS Express\iisexpress.exe' /path:D:\WEB\apps /port:5088 /systray:false
```

Mở http://localhost:5088/ hoặc http://localhost:5088/TrangChu.aspx. TrangMacDinh.aspx được cấu hình làm trang mặc định để tự chuyển đến TrangChu.aspx.
Web Forms cần IIS/ASP.NET trên .NET Framework; không chạy bằng Live Server hoặc `dotnet run`.

## Cấu trúc hiện tại

- `apps/Site.Master`: khung trang, header, thanh điều hướng dùng chung và footer.
- `apps/TrangChu.aspx`: trang chủ, giữ banner và hình ảnh quảng bá; không còn danh sách sản phẩm mẫu.
- `apps/PCMayTinh.aspx`: trang danh mục PC/Máy tính để bàn.
- `apps/MayTinhXachTay.aspx`: trang danh mục Laptop (máy tính xách tay).
- `apps/PhuKien.aspx`: trang danh mục phụ kiện.
- `apps/LinhKien.aspx`: trang danh mục linh kiện.
- `apps/GioiThieu.aspx`: trang giới thiệu.
- `apps/LienHe.aspx`: trang liên hệ.
- `apps/DangNhap.aspx`: giao diện đăng nhập; chưa kết nối xác thực tài khoản.
- `apps/GioHang.aspx`: giao diện giỏ hàng trống; chưa lưu sản phẩm hoặc tạo đơn hàng.
- `apps/TrangMacDinh.aspx`: chuyển hướng đến trang chủ.

Thanh danh mục dùng chung gồm 5 mục: **Trang chủ, PC/Máy tính, Laptop, Phụ kiện, Linh kiện**. Danh mục phụ bên trái trang chủ và các trang danh mục cũ không còn sử dụng đã được loại bỏ.

- `apps/Image/Logo_PCM_Computer.png`: logo PCM Computer mới.

## Phạm vi hiện tại

- Các trang danh mục đang để trống, sẵn sàng cho bước kết nối dữ liệu sau.
- Chưa tạo database, bảng, dữ liệu mẫu hoặc chức năng đọc/ghi dữ liệu.
- Chưa triển khai đăng nhập, giỏ hàng hoặc xử lý nghiệp vụ.
- Các tệp `.html` cũ được giữ lại để đối chiếu bản gốc.
